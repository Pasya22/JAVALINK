<script src="<?= base_url();?>js/style.js"></script>
</body>
</html>