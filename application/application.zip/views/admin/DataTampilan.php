<div id="tampilan-content" class="tampilan-content">
        <div class="container-tampilan">
          <div class="tampilan1">
            <div class="tamp-judul">
              <p class="pes1">Nama Pengguna</p>
              <p>Username Singkat</p>
            </div>
            <div class="tamp1">
              <div class="nama-pengguna">
                <div class="nama-pengguna1">
                  <p><span>javawebster.me</span>/awikwok</p>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil" viewBox="0 0 16 16">
                    <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207 11.207 2.5zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293l6.5-6.5zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325z"/>
                  </svg>
                </div>
                <div class="nama-pengguna2">
                  <p>nama pengguna profil</p>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-sliders" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M11.5 2a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM9.05 3a2.5 2.5 0 0 1 4.9 0H16v1h-2.05a2.5 2.5 0 0 1-4.9 0H0V3h9.05zM4.5 7a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM2.05 8a2.5 2.5 0 0 1 4.9 0H16v1H6.95a2.5 2.5 0 0 1-4.9 0H0V8h2.05zm9.45 4a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zm-2.45 1a2.5 2.5 0 0 1 4.9 0H16v1h-2.05a2.5 2.5 0 0 1-4.9 0H0v-1h9.05z"/>
                  </svg>
                </div>
              </div>
              <div class="username-singkat">
                <div class="username-singkat1">
                  <p><span>jav.me
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-caret-down" viewBox="0 0 16 16">
                      <path d="M3.204 5h9.592L8 10.481 3.204 5zm-.753.659 4.796 5.48a1 1 0 0 0 1.506 0l4.796-5.48c.566-.647.106-1.659-.753-1.659H3.204a1 1 0 0 0-.753 1.659z"/>
                    </svg>
                  </span> /awikwok</p>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil" viewBox="0 0 16 16">
                    <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207 11.207 2.5zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293l6.5-6.5zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325z"/>
                  </svg>
                </div>
                <div class="username-singkat2">
                  <p>nama pengguna singkat</p>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-sliders" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M11.5 2a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM9.05 3a2.5 2.5 0 0 1 4.9 0H16v1h-2.05a2.5 2.5 0 0 1-4.9 0H0V3h9.05zM4.5 7a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM2.05 8a2.5 2.5 0 0 1 4.9 0H16v1H6.95a2.5 2.5 0 0 1-4.9 0H0V8h2.05zm9.45 4a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zm-2.45 1a2.5 2.5 0 0 1 4.9 0H16v1h-2.05a2.5 2.5 0 0 1-4.9 0H0v-1h9.05z"/>
                  </svg>
                </div>
              </div>
            </div>
            <div class="tamp-judul2">
              <p class="pes2">Tata Letak</p>
              <p>Avatar & Judul</p>
            </div>
            <div class="tamp2">
              <div class="tata-letak">
                <h6>Pilih tata letak JavaWebster anda</h6>
                <div class="tata-letak1">
                  <p class="tata-letak11">Free</p>
                  <p class="tata-letak12">PRO</p>
                </div>
                <div class="tata-letak2">
                  <a href=""><img src="img/tataletak1.png" alt=""></a>
                  <a href=""><img src="img/tataletak2.png" alt=""></a>
                </div>
              </div>
              <div class="avatar-judul">
                <div class="avatar-judul1">
                  <svg class="avatar-judul11" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-emoji-smile-fill" viewBox="0 0 16 16">
                    <path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zM7 6.5C7 7.328 6.552 8 6 8s-1-.672-1-1.5S5.448 5 6 5s1 .672 1 1.5zM4.285 9.567a.5.5 0 0 1 .683.183A3.498 3.498 0 0 0 8 11.5a3.498 3.498 0 0 0 3.032-1.75.5.5 0 1 1 .866.5A4.498 4.498 0 0 1 8 12.5a4.498 4.498 0 0 1-3.898-2.25.5.5 0 0 1 .183-.683zM10 8c-.552 0-1-.672-1-1.5S9.448 5 10 5s1 .672 1 1.5S10.552 8 10 8z"/>
                  </svg>
                  <div class="avatar-judul12-wrapper">
                    <button class="avatar-judul12" onclick="document.getElementById('file-input').click()">Unggah Avatar</button>
                  </div>
                  <input type="file" id="file-input" style="display: none" />
                </div>
                <div class="avatar-judul2">
                  <p>Trie102</p>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil" viewBox="0 0 16 16">
                    <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207 11.207 2.5zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293l6.5-6.5zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325z"/>
                  </svg>  
                </div>
                <div class="avatar-judul3">
                  <p>Judul Profil <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
                    <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                    <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
                  </svg></p>
                </div>
                <div class="avatar-judul4">
                  <p>Sembunyikan Avatar</p>
                  <div class="avatar-judul42">
                    <p>MATI</p>
                    <label class="switchh">
                      <input type="checkbox" id="toggle" />
                      <span class="sliderr"></span>
                    </label>
                    <div class="avatar-judulpro">
                      <p>PADA</p>
                      <p class="avatar-judulpro1"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-lock-fill" viewBox="0 0 16 16">
                        <path d="M8 1a2 2 0 0 1 2 2v4H6V3a2 2 0 0 1 2-2zm3 6V3a3 3 0 0 0-6 0v4a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z"/>
                      </svg> PRO</p>
                    </div>                    
                  </div>
                </div>
                <div class="avatar-judul5">
                  <p>Sembunyikan Judul</p>
                  <div class="avatar-judul52">
                    <p>MATI</p>
                    <label class="switchh2">
                      <input type="checkbox" id="toggle" />
                      <span class="sliderr2"></span>
                    </label>
                    <div class="avatar-judulpro2">
                      <p>PADA</p>
                      <p class="avatar-judulpro21"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-lock-fill" viewBox="0 0 16 16">
                        <path d="M8 1a2 2 0 0 1 2 2v4H6V3a2 2 0 0 1 2-2zm3 6V3a3 3 0 0 0-6 0v4a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z"/>
                      </svg> PRO</p>
                    </div>                    
                  </div>
                </div>
              </div>
            </div>
            <div class="tamp-judul3">
              <p class="pes3">Kode QR</p>
            </div>
            <div class="tamp3">
              <div class="kode-qr">
                <p>Berikan Kode QR disini</p>
              </div>
            </div>
            <div class="tamp-judul4">
              <p class="pes4">Keterangan</p>
            </div>
            <div class="tamp4">
              <div class="keterangan">
                <p>Berikan Keterangan disini</p>
              </div>
            </div>
            <div class="tamp-judul5">
              <p class="pes5">Highlight</p>
            </div>
            <div class="tamp5">
              <div class="highlight">
                <p>Berikan Highlight disini</p>
              </div>
            </div>
            <div class="tamp-judul6">
              <p class="pes6">Flash Messege</p>
            </div>
            <div class="tamp6">
              <div class="flash-messege">
                <p>Berikan Flash Messege disini</p>
              </div>
            </div>
            <div class="tamp-judul7">
              <p class="pes7">Avatar Custom</p>
            </div>
            <div class="tamp7">
              <div class="avatar-custom">
                <div class="container-avacus">
                  <div class="container-avacus12">
                    <img src="img/avatarcustom.png" alt="">
                  </div>
                  <div class="container-avacus2">
                    <img src="img/avatarcustom1.png" alt="">
                  </div>
                  <div class="container-avacus2">
                    <img src="img/avatarcustom2.png" alt="">
                  </div>
                  <div class="container-avacus2">
                    <img src="img/avatarcustom3.png" alt="">
                  </div>
                  <div class="container-avacus2">
                    <img src="img/avatarcustom4.png" alt="">
                  </div>
                  <div class="container-avacus2">
                    <img src="img/avatarcustom5.png" alt="">
                  </div>
                </div>
              </div>
            </div>
            <div class="tamp-judul8">
              <p class="pes8">Tema</p>
            </div>
            <div class="tamp8">
              <div class="tema">
                <div class="container-tema1">
                  <ul>
                    <li id="tema-all" onclick="showContent('tema-all')">All</li>
                    <li id="tema-free" onclick="showContent('tema-free')">Free</li>
                    <li id="tema-patterns" onclick="showContent('tema-patterns')">Patterns</li>
                    <li id="tema-crypto" onclick="showContent('tema-crypto')">Crypto</li>
                    <li id="tema-templates" onclick="showContent('tema-templates')">Templates</li>
                    <li id="tema-countries" onclick="showContent('tema-countries')">Countries</li>
                    <li id="tema-pro" onclick="showContent('tema-pro')">PRO</li>
                    <li id="tema-christimas" onclick="showContent('tema-christimas')">Christimas</li>
                    <li id="tema-newyear" onclick="showContent('tema-newyear')">Lunar New Year</li>
                    <li id="tema-holidays" onclick="showContent('tema-holidays')">Holidays</li>
                    <li id="tema-partnership" onclick="showContent('tema-partnership')">Partnership</li>
                  </ul>
                </div>
                <div class="content-container-tema">
                  <div id="tema-all-content" style="display: none;">
                    <div class="container-tema-all">
                      <div class="container-tema-custom">
                        <div class="container-tema-custom1">
                          <p>CREATE YOUR OWN</p>
                        </div>
                        <div class="container-tema-custom2">
                          <p>Tema Custom</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div id="tema-free-content" style="display: none;">
                    <div class="container-tema-all">
                      <div class="container-tema-custom">
                        <div class="container-tema-custom1">
                          <p>CREATE YOUR OWN</p>
                        </div>
                        <div class="container-tema-custom2">
                          <p>Tema Custom</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div id="tema-patterns-content" style="display: none;">
                    <div class="container-tema-all">
                      <div class="container-tema-custom">
                        <div class="container-tema-custom1">
                          <p>CREATE YOUR OWN</p>
                        </div>
                        <div class="container-tema-custom2">
                          <p>Tema Custom</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div id="tema-crypto-content" style="display: none;">
                    <div class="container-tema-all">
                      <div class="container-tema-custom">
                        <div class="container-tema-custom1">
                          <p>CREATE YOUR OWN</p>
                        </div>
                        <div class="container-tema-custom2">
                          <p>Tema Custom</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div id="tema-templates-content" style="display: none;">
                    <div class="container-tema-all">
                      <div class="container-tema-custom">
                        <div class="container-tema-custom1">
                          <p>CREATE YOUR OWN</p>
                        </div>
                        <div class="container-tema-custom2">
                          <p>Tema Custom</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div id="tema-countries-content" style="display: none;">
                    <div class="container-tema-all">
                      <div class="container-tema-custom">
                        <div class="container-tema-custom1">
                          <p>CREATE YOUR OWN</p>
                        </div>
                        <div class="container-tema-custom2">
                          <p>Tema Custom</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div id="tema-pro-content" style="display: none;">
                    <div class="container-tema-all">
                      <div class="container-tema-custom">
                        <div class="container-tema-custom1">
                          <p>CREATE YOUR OWN</p>
                        </div>
                        <div class="container-tema-custom2">
                          <p>Tema Custom</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div id="tema-christimas-content" style="display: none;">
                    <div class="container-tema-all">
                      <div class="container-tema-custom">
                        <div class="container-tema-custom1">
                          <p>CREATE YOUR OWN</p>
                        </div>
                        <div class="container-tema-custom2">
                          <p>Tema Custom</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div id="tema-newyear-content" style="display: none;">
                    <div class="container-tema-all">
                      <div class="container-tema-custom">
                        <div class="container-tema-custom1">
                          <p>CREATE YOUR OWN</p>
                        </div>
                        <div class="container-tema-custom2">
                          <p>Tema Custom</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div id="tema-holidays-content" style="display: none;">
                    <div class="container-tema-all">
                      <div class="container-tema-custom">
                        <div class="container-tema-custom1">
                          <p>CREATE YOUR OWN</p>
                        </div>
                        <div class="container-tema-custom2">
                          <p>Tema Custom</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div id="tema-partnership-content" style="display: none;">
                    <div class="container-tema-all">
                      <div class="container-tema-custom">
                        <div class="container-tema-custom1">
                          <p>CREATE YOUR OWN</p>
                        </div>
                        <div class="container-tema-custom2">
                          <p>Tema Custom</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                      <div class="desain-tema1">
                        <div class="desain-tema11"></div>
                        <div class="desain-tema12">
                          <p>Carulean Blue</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="tamp-judul9">
              <p class="pes9">Tata Teks Header</p>
            </div>
            <div class="tamp9">
              <div class="tata-teks-header">
                <div class="container-tata-teks-header">
                  <div class="tata-teks-header1">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-text-left" viewBox="0 0 16 16">
                      <path fill-rule="evenodd" d="M2 12.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm0-3a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5zm0-3a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm0-3a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5z"/>
                    </svg>
                    <p>Kiri</p>
                  </div>
                  <div class="tata-teks-header2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-text-center" viewBox="0 0 16 16">
                      <path fill-rule="evenodd" d="M4 12.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm-2-3a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5zm2-3a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm-2-3a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5z"/>
                    </svg>
                    <p>Tengah</p>
                  </div>
                  <div class="tata-teks-header3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-text-right" viewBox="0 0 16 16">
                      <path fill-rule="evenodd" d="M6 12.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm-4-3a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5zm4-3a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm-4-3a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5z"/>
                    </svg>
                    <p>Kanan</p>
                  </div>
                </div>
              </div>
            </div>
            <div class="tamp-judul10">
              <p class="pes10">Penyesuaian Teks Link</p>
            </div>
            <div class="tamp10">
              <div class="penyesuaian-teks-link">
                <div class="container-penyesuaian-teks-link">
                  <div class="penyesuaian-teks-link1">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-text-left" viewBox="0 0 16 16">
                      <path fill-rule="evenodd" d="M2 12.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm0-3a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5zm0-3a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm0-3a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5z"/>
                    </svg>
                    <p>Kiri</p>
                  </div>
                  <div class="penyesuaian-teks-link2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-text-center" viewBox="0 0 16 16">
                      <path fill-rule="evenodd" d="M4 12.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm-2-3a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5zm2-3a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm-2-3a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5z"/>
                    </svg>
                    <p>Tengah</p>
                  </div>
                  <div class="penyesuaian-teks-link3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-text-right" viewBox="0 0 16 16">
                      <path fill-rule="evenodd" d="M6 12.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm-4-3a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5zm4-3a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm-4-3a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5z"/>
                    </svg>
                    <p>Kanan</p>
                  </div>
                </div>
              </div>
            </div>
            <div class="tamp-judul11">
              <p class="pes11">Replikasi Tema JavaWebster Yang Ada</p>
            </div>
            <div class="tamp11">
              <div class="replikasi-tema">
                <p>Berikan Replikasi Tema disini</p>
              </div>
            </div>
            <div class="tamp-judul12">
              <p class="pes12">Favicon</p>
            </div>
            <div class="tamp12">
              <div class="favicon-tema">
                <div class="container-favicon-tema">
                  <p>Tambahkan Favicon</p>
                  <label class="favicon-tema1" for="">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-share" viewBox="0 0 16 16">
                      <path d="M13.5 1a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM11 2.5a2.5 2.5 0 1 1 .603 1.628l-6.718 3.12a2.499 2.499 0 0 1 0 1.504l6.718 3.12a2.5 2.5 0 1 1-.488.876l-6.718-3.12a2.5 2.5 0 1 1 0-3.256l6.718-3.12A2.5 2.5 0 0 1 11 2.5zm-8.5 4a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zm11 5.5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3z"/>
                    </svg>
                  </label> 
                  <div class="favicon-tema2">
                    <button class="favicon-tema21" onclick="document.getElementById('file-input').click()">Unggah File</button>
                    <input type="file" id="file-input" style="display: none" />
                  </div>
                </div>
              </div>
            </div>
            <div class="tamp-judul13">
              <p class="pes13">Footer</p>
            </div>
            <div class="tamp13">
              <div class="footer-tema">
                <div class="container-footer-tema">
                  <div class="footer-tema11">
                    <p>Sembunyikan Logo JavaWebster.me</p>
                    <div class="footer-tema12">
                      <p>MATI</p>
                      <label class="footer-switch">
                        <input type="checkbox" id="toggle" />
                        <span class="footer-slider"></span>
                      </label>
                      <p>PADA</p>
                    </div>
                  </div>
                  <div class="footer-tema21">
                    <p>Sembunyikan (i)kon</p>
                    <div class="footer-tema22">
                      <p>MATI</p>
                      <label class="footer-switch2">
                        <input type="checkbox" id="toggle" />
                        <span class="footer-slider2"></span>
                      </label>
                      <p>PADA</p>
                    </div>
                  </div>
                  <div class="footer-tema3">
                    <p>Tambagkan Logo Anda Sendiri</p>
                    <span>Format yang disarankan untuk logo adalah Png dan JPG dan tidak boleh melebihi 2MB</span>
                    <div class="footer-logo-tema">
                      <img src="img/javawebster.png" alt="">
                      <p>JavaWebster.me</p>
                    </div>
                    <div class="footer-logo-tema2">
                      <button class="footer-logo-tema21" onclick="document.getElementById('file-input').click()">Unggah File</button>
                      <input type="file" id="file-input" style="display: none" />
                    </div>
                    <div class="footer-logo-tema3">
                      <p>Tambahkan Teks Alt</p>
                      <div class="footer-logo-tema31">
                        <label for="">Tambahkan tautan (opsional)</label>
                        <input type="text" placeholder="Url Link">
                      </div>
                      <div class="footer-logo-tema32">
                        <label for="">Posisi Logo</label>
                        <select name="" id="">
                          <option value="">Right</option>
                          <option value="">Left</option>
                          <option value="">Center</option>
                        </select>
                      </div>
                      <div class="footer-logo-tema33">
                        <label for="">Ukuran Logo</label>
                        <select name="" id="">
                          <option value="">Medium</option>
                          <option value="">Hard</option>
                          <option value="">Easy</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="tampilan2">
            <div class="conthp">
              <div class="tampilan2-share">
                <div class="container-tampilan2-share">
                  <div class="tampilan2-share1">
                    <p>Share JavaWebster</p>
                    <svg onclick="clicksvghp2()" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle-fill" viewBox="0 0 16 16">
                      <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM5.354 4.646a.5.5 0 1 0-.708.708L7.293 8l-2.647 2.646a.5.5 0 0 0 .708.708L8 8.707l2.646 2.647a.5.5 0 0 0 .708-.708L8.707 8l2.647-2.646a.5.5 0 0 0-.708-.708L8 7.293 5.354 4.646z"/>
                    </svg>
                  </div>
                  <div class="tampilan2-share2">
                    <label for="">https://app.heylink.me/appearance</label>
                    <img src="img/copy-link.png" alt="">
                  </div>
                  <div class="tampilan2-share3">
                    <div class="tampilan2-share3-fb">
                      <img src="img/fb.png" alt="">
                      <p>Share on Facebook</p>
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-right" viewBox="0 0 16 16">
                        <path fill-rule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z"/>
                      </svg>
                    </div>
                    <div class="tampilan2-share3-telegram">
                      <img src="img/telegram.png" alt="">
                      <p>Share on Telegram</p>
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-right" viewBox="0 0 16 16">
                        <path fill-rule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z"/>
                      </svg>
                    </div>
                    <div class="tampilan2-share3-twitter">
                      <img src="img/twitter.png" alt="">
                      <p>Share on Twitter</p>
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-right" viewBox="0 0 16 16">
                        <path fill-rule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z"/>
                      </svg>
                    </div>
                    <div class="tampilan2-share3-linkedin">
                      <img src="img/linkedin.png" alt="">
                      <p>Share on Linkedin</p>
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-right" viewBox="0 0 16 16">
                        <path fill-rule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z"/>
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
              <div class="conthp2">
                <div class="pos1"></div>
                <div class="pos2"></div>
                <div class="pos3">
                  <svg class="pos31" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-emoji-smile-fill" viewBox="0 0 16 16">
                    <path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zM7 6.5C7 7.328 6.552 8 6 8s-1-.672-1-1.5S5.448 5 6 5s1 .672 1 1.5zM4.285 9.567a.5.5 0 0 1 .683.183A3.498 3.498 0 0 0 8 11.5a3.498 3.498 0 0 0 3.032-1.75.5.5 0 1 1 .866.5A4.498 4.498 0 0 1 8 12.5a4.498 4.498 0 0 1-3.898-2.25.5.5 0 0 1 .183-.683zM10 8c-.552 0-1-.672-1-1.5S9.448 5 10 5s1 .672 1 1.5S10.552 8 10 8z"/>
                  </svg>
                  <svg onclick="clicksvghp()" class="pos32" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-share-fill" viewBox="0 0 16 16">
                    <path d="M11 2.5a2.5 2.5 0 1 1 .603 1.628l-6.718 3.12a2.499 2.499 0 0 1 0 1.504l6.718 3.12a2.5 2.5 0 1 1-.488.876l-6.718-3.12a2.5 2.5 0 1 1 0-3.256l6.718-3.12A2.5 2.5 0 0 1 11 2.5z"/>
                  </svg>
                </div>
                <div class="pos4"><p>TriBuwono01</p></div>
                <div class="pos5">
                  <a href="" class="pos51">
                    <p>Javawebster.link</p>
                  </a>
                  <svg class="pos53" onclick="clicksvghp()" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-share-fill" viewBox="0 0 16 16">
                    <path d="M11 2.5a2.5 2.5 0 1 1 .603 1.628l-6.718 3.12a2.499 2.499 0 0 1 0 1.504l6.718 3.12a2.5 2.5 0 1 1-.488.876l-6.718-3.12a2.5 2.5 0 1 1 0-3.256l6.718-3.12A2.5 2.5 0 0 1 11 2.5z"/>
                  </svg>
                </div>
                <div class="pos6">
                  <div class="pos61">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
                      <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                      <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
                    </svg>
                    <p>Cookies Preferences</p>
                  </div>
                  <div class="pos62">
                     <a href=""><img src="img/javawebster.png" alt="">JavaWebster</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>